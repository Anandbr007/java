package JavaBasics;

public class Constructors {

	//constructor is a block of code which is used to initialize an object of class
	//syntax it is similar to method but without return type
	//constructor within the class allows constructing the object of the class at runtime
	//how constructor is invoked?-->using new keyword
	//constructs also accept parameters and it can overload
	String name;
	int age;
	String address;
	
	Constructors(){
		 name="anand";
		 age=23;
		 address="PERRORKADA";
	}
	
	void display() {
		System.out.println("name: "+name);
	}
	
	public static void main(String[] args) {
		Constructors c=new Constructors();
		c.display(); 
	}
}
