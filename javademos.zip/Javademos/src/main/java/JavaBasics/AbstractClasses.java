package JavaBasics;
									//we cannot create object

abstract class AbstractClasses {
	public abstract void getsample() ;//abstract method
									  
	
	public static void setsample() {//normal method
		
	}
		
	
}
