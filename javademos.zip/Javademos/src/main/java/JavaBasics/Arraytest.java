package JavaBasics;

import java.util.Scanner;

public class Arraytest {
	
public static void main(String[] args) {
	System.out.println("enter array size");
	Scanner sc=new Scanner(System.in);
	int size=sc.nextInt();
	int arr[]=new int[size];
	System.out.println("enter array elements");
	for(int i=0;i<arr.length;i++) {
		arr[i]=sc.nextInt();
	}
	Arraytest obj=new Arraytest();
	int max=obj.findMax(arr);
	System.out.println("the largest number : "+max);
}

int findMax(int array[]) {
	int max=0;
	for(int i=0;i<array.length;i++) {
		if(max < array[i]) {
			max=array[i];
		}
		
	}
	
	return max;
}
}
