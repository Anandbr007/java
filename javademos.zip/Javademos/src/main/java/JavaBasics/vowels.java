package JavaBasics;

import java.util.Scanner;

public class vowels {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("enter the name :");
		String name=sc.next();
		
		for(int i=0;i<name.length();i++) {
			if(name.charAt(i)=='a' || name.charAt(i)=='e' || name.charAt(i)=='i' || name.charAt(i)=='o' || name.charAt(i)=='u') {
				System.out.println("the vowel "+name.charAt(i)+" at index :"+(i+1));
			}
		}
	}
}
