package JavaBasics;

public class forloop {

	public static void main(String[] args) {
		int n = 0;
		for(int i=1;i<=15;i+=2) {
			
			 System.out.print(" "+i);
		}
	}
}
