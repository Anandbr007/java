package JavaBasics;

public class helloworld {
public static void main(String[] args) {
	System.out.println("hello world");
	System.out.println("hii im anand");
}
}
