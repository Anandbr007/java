package JavaBasics;

class Parent{
	int a=50;
	String s="hello world";
}
class child extends Parent{
	int a =60;
	String s="happy coding";
	
	void display() {
		System.out.println("the value of super"+super.a);
		
		System.out.println("the value of this"+this.a);
	}

}


public class ThisandSuper2 {

	//super keyword
	//is used to refer the instance of immediate parent class
	//it is used to invoke the  method of immediate parent class
	public static void main(String[] args) {
		child obj=new child();
		obj.display();
	}
	
}
