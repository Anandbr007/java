package JavaBasics;

public class Loops {

	public static void main(String[] args) {
		int marks[][]= {
				{23,34,56},
				{34,45,90},
				{34,56,22}
		};
		
		int marks1[][]= {
				{34,45,90},
				{34,56,22},
				{23,34,56}
		};
		int marks2[][] = new int[3][3];
		
		for(int i=0;i<marks.length;i++) {
			for(int j=0;j<marks[i].length;j++) {
				System.out.print(marks[i][j]+" ");
			}
			System.out.println();
		}
		
		System.out.println("\n");
		
		for(int i=0;i<marks1.length;i++) {
			for(int j=0;j<marks1[i].length;j++) {
				System.out.print(marks1[i][j]+" ");
			}
			System.out.println();
		}
		System.out.println("\n");
		
		for(int i=0;i<marks.length;i++) {
			for(int j=0;j<marks[i].length;j++) {
				marks2[i][j]=marks[i][j]*marks1[i][j];
				System.out.println(marks2[i][j]+" ");
			}
			System.out.println();
		}
		
	
		
		
	}
}
