package JavaBasics;

public class While {


	public static void main(String[] args) {
		int i=1,j=1;
		while(i<6) 
		{
			while(j<6) 
			{
				System.out.print(j+" ");
				j++;
				
			}
			j=1;
			System.out.println();
			i++;
		}
	}
}
