package JavaBasics;

import java.util.Scanner;

public class DoWhile {
	
	
	public static void main(String[] args) {
		int i;
		do {
			System.out.println("enter a number between 1 and 10 :");
			Scanner sc=new Scanner(System.in);
			i=sc.nextInt();
		}while(!(i>=1&&i<=10));
		System.out.println("valid");
	}

	
}
