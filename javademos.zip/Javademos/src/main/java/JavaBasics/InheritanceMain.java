package JavaBasics;

class Superclass{
	void methodSuper() {
		System.out.println("im a super class");
	}
}


class Subclass extends Superclass{
	void methodsuper() {
		System.out.println("im a sub class");
	}
}


public class InheritanceMain {
	
public static void main(String[] args) {
//	Subclass s=new Subclass();
//	s.methodsub();
	Superclass sp=new Subclass();
	
	sp.methodSuper();
}
}
