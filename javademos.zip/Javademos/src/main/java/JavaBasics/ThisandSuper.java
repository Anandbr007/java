package JavaBasics;

public class ThisandSuper {

	//this keyword
	//is used to refer the current object

	int instanceVar=5;
	static int staticVar=10;
	 void display() {
		//method specific variable
		int instanceVar=6;
		int staticVar=11;
		
		//referring to the current class instance and static variables
		this.instanceVar=50;
		this.staticVar=100;
		
		
		System.out.println("value of instance var: "+this.instanceVar);
		System.out.println("value of instance var: "+this.staticVar);
		
		//printing method specific var
		System.out.println("value of instance var: "+instanceVar);
		System.out.println("value of instance var: "+staticVar);
		
	}
	public static void main(String[] args) {
		ThisandSuper t=new ThisandSuper();
		t.display();
	}

}
