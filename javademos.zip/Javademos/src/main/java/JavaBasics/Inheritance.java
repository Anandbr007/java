package JavaBasics;

public class Inheritance {

	//why do we need OOps concepts  in java
	
	//real world modelling-create obj tht represent real world entites
	//reusability
	//data hiding and security
	//maintainability
	//large applications
	
	//super class<--inherits(extends)--subclass
	
	
	
	//types of inheritance
	
	//single===superclass--extends->subclass
	//multilevel=====superclass--extends->subclass--extends->subclass2
	//hierarchichal -one super class is inherited separately by two or more subclasses
	//mutiple-single class inherits from two superclasses(for class not supprt in java)(we can do it using interface)
	//hybrid
	
}
