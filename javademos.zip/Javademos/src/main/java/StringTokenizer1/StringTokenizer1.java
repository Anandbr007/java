package StringTokenizer1;

import java.util.Scanner;
import java.util.StringTokenizer;

public class StringTokenizer1 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String name=sc.nextLine();
		StringTokenizer str=new StringTokenizer(name);
		
		
		StringBuffer sb=new StringBuffer();
		
		String s2=str.nextToken();
		String s3=str.nextToken();
		sb.append(s3).append(",");
		sb.append(s2.substring (0,1).toUpperCase());
		
		System.out.println(sb);
		
	}
}


		
