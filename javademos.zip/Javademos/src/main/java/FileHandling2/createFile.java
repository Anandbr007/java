package FileHandling2;

import java.io.File;

public class createFile {

	public static void main(String[] args) {
		try {
			String projectPath=System.getProperty("user.dir");
//			System.out.println(projectPath);
			File f=new File(projectPath+"\\src\\main\\java\\FileHandling2\\myFile.txt");//file path as string
			
				boolean value=f.createNewFile();
				if(value) {
					System.out.println("new file is created");
				}else {
					System.out.println("file already exists");
				}
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
