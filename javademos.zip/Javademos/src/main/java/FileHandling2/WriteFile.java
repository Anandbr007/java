package FileHandling2;

public class WriteFile {

}
