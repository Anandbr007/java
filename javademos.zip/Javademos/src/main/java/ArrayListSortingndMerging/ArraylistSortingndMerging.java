package ArrayListSortingndMerging;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class ArraylistSortingndMerging {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		ArrayList<Integer> al=new ArrayList<Integer>();
		ArrayList<Integer> al1=new ArrayList<Integer>();
		for(int i=0;i<5;i++) {
			al.add(sc.nextInt());
		}
		for(int i=0;i<5;i++) {
			al1.add(sc.nextInt());
		}
		
		al.addAll(al1);
		
		Collections.sort(al);
		
		ArrayList<Integer> result=new ArrayList<Integer>();
		
		for(int i=2;i<10;i=i+2) {
			if(i==4)
				continue;
			else
				result.add(al.get(i));
		}
		System.out.print(result);
		
	}
	
	
	
}
