package SumofEvenNo;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class UserMainCode {

	static int addUniqueEven(int input[]) {
		
		int sum=0;
		HashSet<Integer> hs=new HashSet<Integer>();
		for(int i=0;i<input.length;i++) {
			hs.add(input[i]);
		}
		
		
		for(int i:hs) {
			if(i%2==0) {
				sum+=i;
			}
			}
		return sum;
		
	}
}
