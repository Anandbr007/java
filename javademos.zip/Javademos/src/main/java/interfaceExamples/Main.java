package interfaceExamples;

public class Main {

	public static void main(String[] args) {
		Car c=new Car();
		Train t=new Train();
		MotorisedVehicle mv=new MotorisedVehicle();
		c.drive();
		c.brake();
		c.turnLeft();
		c.checkMotor();
		
		t.brake();
		t.drive();
		t.turnLeft();
		
	}
	
}
