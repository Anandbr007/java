package interfaceExamples;

public interface IPublicTransport {
	public void getNumberOfPeople();
}
