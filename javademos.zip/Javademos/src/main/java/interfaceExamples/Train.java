package interfaceExamples;

import java.util.Scanner;

public class Train implements IVehicle,IPublicTransport{

	@Override
	public void getNumberOfPeople() {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter number of people");
		int count=sc.nextInt();
		System.out.println(count+" number of people ");
	}

	@Override
	public void drive() {
		System.out.println("the train is in drive mode");
		
	}

	@Override
	public void turnLeft() {
		System.out.println("the train is turning left");
		
	}

	@Override
	public void brake() {
		System.out.println("the train is in brake mode");
		
	}
	
	

}
