package interfaceExamples;

public class MotorisedVehicle {

	void checkMotor() {
		System.out.println("the motor of the vehicle is in good condition");
	}
	
}
