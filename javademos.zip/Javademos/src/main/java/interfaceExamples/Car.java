package interfaceExamples;

public class Car extends MotorisedVehicle implements IVehicle{

	@Override
	public void drive() {
		System.out.println("the car is in drive mode");
		
	}

	@Override
	public void turnLeft() {
		System.out.println("the car is turning left");
		
	}

	@Override
	public void brake() {
		System.out.println("the car is in brake mode");
		
	}

	
}
