package BankManagementSystem2;

public class SavingsAccount extends BankAccount {
	
	private double interestRate;

	SavingsAccount(String accountNumber, String accountHolder, double balance) {
		super(accountNumber, accountHolder, balance);
		this.interestRate = interestRate;
		
	}
	
	void displayAccountDetails() {
		System.out.println("Interest Rate :"+this.interestRate);
	}

	public double getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(double interestRate) {
		this.interestRate = interestRate;
	}
	
}
