package BankManagementSystem2;

public class BankAccount {

//	accountNumber (String), accountHolder (String), balance (double).
	private String accountNumber;
	private String accountHolder;
	private double balance;
	
	
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getAccountHolder() {
		return accountHolder;
	}
	public void setAccountHolder(String accountHolder) {
		this.accountHolder = accountHolder;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	
	BankAccount(String accountNumber,String accountHolder,double balance) {
		this.accountNumber=accountNumber;
		this.accountHolder=accountHolder;
		this.balance=balance;
		
	}
	
	double deposit(double amount) {
		balance+=amount;
		
		return balance;
	}
	
	double withdraw(double amount) {
		if(amount<=balance) {
			return 0;
		}else
			return -1;
	}
	
	 void displayAccountDetails() {
		 System.out.println("Your AccountNumber :"+accountNumber);
		 System.out.println("AccountHolder Name :"+accountHolder);
		 System.out.println("Your Balance :"+balance);
		 
		 //account type
	 }

}
