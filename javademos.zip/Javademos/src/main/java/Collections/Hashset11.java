package Collections;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Hashset11 {

	public static void main(String[] args) {
		List<String> list=new ArrayList<String>();
		
		list.add("suits");
		list.add("berlin");
		list.add("money heist");
		list.add("money heist");
		System.out.println(list);
		
		Set<String> set=new HashSet<String>();
		set.addAll(list);
		System.out.println(set);
		// set.removeAll(set2);
		//set.remove(10);
	}
	
	
}
