package Collections;

import java.util.Iterator;
import java.util.LinkedList;

public class Collectionss {

	
	//what is collection in java ?  it can handle homogenous ND heterogenous
	//collection framework-list,set,queue,map
	//how collection is  better than array?
		//no limitation on size of elements
		//utility methods-searching,sorting,replacing,removing by methods 
	
	//why  collections?
		//less effort
		//more readability and maintainability
	
	//when to use collection?
		//if we need to save multiple objects without limits on their type or size
	
	//when to use list?-ordered collection
		//maintain an order of elements
		//allow duplicates
		//retrieve the elements based on index
		//iterate over elements in a specific order
	
	//when to use set?-unordered collection
		//eliminates duplicates
		//store unique elements
		//ignore the order
	
	//when to use map?=unordered collection
	
		//store key-value pairs where each key is unique and maps to its single value
		//key is used to retrieve the value
	
	
	//when to use queue?-ordered collection
		//store elements in FIFO order
		//add elements in end of the queue
		//remove the elements from front of queue
	
	//list-arraylist,linkedlist,stack,vector
	//methods-add(),get(),indexOf(),remove(element) or remove(index),set(index,element),size(),contains(element)
	
	//iterating from list
	//iterator()
	//	Iterator<String> itr=list.iterator();
	//	while(itr.hasNext()) {
	//		String s=itr.next();
	//	}
	
	//sort the list
		//Collection.sort(list)
	
	//create a sublist
		//List sublist=list.subList(1,3);
	//convert to array
		//list.toArray
	
	//Linkedlist-a linear data structure used to store elements in contiguous locations
	//data part and address part

		//LinkedList<String> trainlist=new LinkedList<String>();
		
	
		//adding
		//trainlist.add("dfdfd");
		//trainlist.addFirst("ffg");
		//trainlist.addlast("sdh");
	
	
}
