package Collections;

import java.util.LinkedList;

public class Linkedlist11 {

	public static void main(String[] args) {
		//it also inherits the behaviour of 'dequeue'
		//it allows you to perform operation in head and tail-->POP and peek
		//pop-->removes and return the first element of list
		//when linkedlist used as stack,it follows LIFO
		//peek-->inspect the first element of list without modifying it
		//when linkedlist used as queue,it follows FIFO
		
		LinkedList<String> names=new LinkedList<String>();
		names.add("anand");
		names.peek();
		names.pop();
	
	}
}
