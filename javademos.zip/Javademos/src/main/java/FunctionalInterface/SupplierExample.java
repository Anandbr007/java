package FunctionalInterface;

import java.time.LocalDate;
import java.util.Random;
import java.util.function.Supplier;





public class SupplierExample {

	public static void main(String[] args) {
		Supplier<Integer> s=()->new Random().nextInt(100);
		int randomNumber=s.get();
		System.out.println(randomNumber);
		
		Supplier<LocalDate> randomDateSupplier=()->{
			Random random=new Random();
			int minYear=2000;
			int maxYear=2020;
			int randomYear=random.nextInt(maxYear-minYear+1)+minYear;
			int randomMonth=random.nextInt(12)+1;
			return null;
			
		};
	}
}
