package FunctionalInterface;

import java.util.function.Predicate;

public class PredicateExample {

	public static void main(String[] args) {
		// Predicate--> taking one argument and returns a boolean value
		// commonly used for filtering,testing and validation
		Predicate<Person> predicate=(p)->p.getAge()>28;
		boolean result=predicate.test(new Person("roshan",29));
		System.out.println(result);
	}
	
}
