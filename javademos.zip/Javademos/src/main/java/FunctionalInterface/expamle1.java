package FunctionalInterface;

public class expamle1 {
public static void main(String[] args) {
	example1 exp=(i)->i*i;
	System.out.println(exp.squareofanumber(5));
}
}
