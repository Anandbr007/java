package FunctionalInterface;

import java.util.ArrayList;

public class IteratingList {
//without lambda
	public static void main(String[] args) {
		ArrayList<String> al=new ArrayList<String>();
		al.add("roshan");
		al.add("dijo");
		al.add("gautham");
		al.add("anand");
		
		for(String str : al) {
			System.out.println(str);
		}
		
		
		
	}
	
	
}
