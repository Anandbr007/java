package FunctionalInterface;

interface CheckPerson{
	boolean test(Person p);
}
public class main implements CheckPerson {

	public boolean test(Person p) {
		if(p.getAge()>28)
			return true;
		else {
			return false;
		}	
	}
	
	
	public static void main(String[] args) {
//		Person p=new Person("ramesh", 29);
		main obj=new main();
		System.out.println(obj.test(new Person("ramesh", 29)));
	}
	
	
}
