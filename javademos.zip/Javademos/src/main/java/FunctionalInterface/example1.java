package FunctionalInterface;


public interface example1 {

	public int squareofanumber(int i);
}
