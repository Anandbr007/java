package FunctionalInterface;

interface I5{
	public void m1(String str);
		
	
}
//using lambda
public class StringwithLambda {

	public static void main(String[] args) {
		I5 obj=(str)->{
			System.out.println(str.toUpperCase());
		};
		obj.m1("roshan is a chathan");
	}
}
