package FunctionalInterface;

public class sumoftwonumber {
public static void main(String[] args) {
	
	SumofTwoNumbers sm=(a,b)->a+b;
	System.out.println(sm.sum(3, 4));
	
	
}
}
