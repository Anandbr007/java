package FunctionalInterface;



public interface SumofTwoNumbers {
	public int sum(int a,int b);
 
}
