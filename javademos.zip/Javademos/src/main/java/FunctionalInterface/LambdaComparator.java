package FunctionalInterface;

import java.util.ArrayList;
import java.util.List;



class book{
	int bookid;
	String bookname;
	public book(int bookid,String bookname) {
		this.bookid=bookid;
		this.bookname=bookname;
	}
}


public class LambdaComparator {

	
	public static void main(String[] args) {
		//creating the list of books
		List<book> list=new ArrayList<book>();
		
		list.add(new book(2, "five point someone"));
		list.add(new book(1, "the secret"));
		list.add(new book(4, "the alchemist"));
		list.add(new book(3, "davinci code"));
		
		System.out.println("before sorting");
		for(book b:list) {
			System.out.println(b.bookid+"-"+b.bookname);
		}
		
		
		System.out.println("after sorting");
		list.sort((b1,b2)->b1.bookname.compareTo(b2.bookname));
		for(book b:list) {
			System.out.println(b.bookid+"-"+b.bookname);
		}
		
		System.out.println("after sorting in descending order");
		list.sort((b1,b2)->b2.bookname.compareTo(b1.bookname));
		for(book b:list) {
			System.out.println(b.bookid+"-"+b.bookname);
		}
	}
	
}
