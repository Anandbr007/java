package FunctionalInterface;

public class helloworldExmple {

	public void m1() {
		System.out.println("hello world");
	}
	public static void main(String[] args) {
		helloworldExmple obj=new helloworldExmple();
		obj.m1();
	}
}
