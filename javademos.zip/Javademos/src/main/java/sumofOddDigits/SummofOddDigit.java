package sumofOddDigits;

import java.util.Scanner;

public class SummofOddDigit {
	
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter number to check :");
	int n=sc.nextInt();
	int output=UserMainCode.checkSum(n);
	if(output==-1) {
		System.out.println("Sum of odd digits is even");
	}
	else
		System.out.println("Sum of odd digits is odd");
	
	
}
}


class UserMainCode{
	static int checkSum(int num) {
		int result=0;
		while(num>0) {
		int rev=num%10;
		if((rev%2!=0)) {
				result+=rev;
			}
		num=num/10;
		}
		if(result%2==0) {
			return -1;
		}
		else
			return 1;
		
	}
}