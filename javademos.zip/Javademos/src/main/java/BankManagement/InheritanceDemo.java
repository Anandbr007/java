package BankManagement;

import java.util.Scanner;

public class InheritanceDemo {
	
public static void main(String[] args) {
	double depositAmount,withdrawAmount;
	Scanner sc=new Scanner(System.in);
	
	System.out.println("enter deposit amount :");
	depositAmount=sc.nextDouble();
	
	System.out.println("enter withdraw amount :");
	withdrawAmount=sc.nextDouble();
	
	System.out.println("Account Type:\n 1)NRI Account\n 2)Senior Citizen");
	int n=sc.nextInt();
	switch(n) {
	case 1: 
		NRIAccount nri=new NRIAccount(withdrawAmount, depositAmount, 0, depositAmount);
		nri.depositMoney();
		nri.withdrawMoney();
		nri.applyFixedDeposit();
		break;
	case 2:
		SeniorCitizen senior=new SeniorCitizen(withdrawAmount, depositAmount, 0, depositAmount);
		senior.depositMoney();
		senior.withdrawMoney();
		senior.applyFixedDeposit();
		break;
	default:
		System.out.println("wrong choice");
		break;
	}
	
	
}
}
