package BankManagement;

class NRIAccount extends BankAccount{
	public NRIAccount(double withdrawAmount, double depositAmount, double interestRate, double balance) {
		super(withdrawAmount, depositAmount, interestRate, balance);
	}

	void applyFixedDeposit() {
		super.interestRate=6.5;
		System.out.println("interest rate :"+super.interestRate);
	}
	
	
}

class SeniorCitizen extends BankAccount{

	public SeniorCitizen(double withdrawAmount, double depositAmount, double interestRate, double balance) {
		super(withdrawAmount, depositAmount, interestRate, balance);
	
	}

	void applyFixedDeposit() {
		super.interestRate=10.5;
		System.out.println("interest rate :"+super.interestRate);
	}
}


public class BankAccount {

	double withdrawAmount,
	depositAmount,
	interestRate ,
	balance;
	
	public BankAccount(double withdrawAmount,double depositAmount,double interestRate,double balance) {
		this.withdrawAmount=withdrawAmount;
		this.depositAmount=depositAmount;
		this.interestRate=interestRate;
		this.balance=balance;
	} 
	
	
	void depositMoney() {
		System.out.println("Your deposit amount :"+ depositAmount);
	}
	
	void withdrawMoney() {
		System.out.println("Your withdraw amount :"+ withdrawAmount);
		if(withdrawAmount<=balance) {
			double balance = depositAmount-withdrawAmount;
			System.out.println("Available Balance :"+balance);
		}
	}
}

