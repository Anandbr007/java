package Flames;

import java.util.Scanner;

public class Flames {
public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		String name1=sc.nextLine();
		String name2=sc.nextLine();
		
		name1=name1.toLowerCase();
		name2=name2.toLowerCase();
		
		///convert both names to stringbuilder for mutable
		StringBuilder sb1 = new StringBuilder(name1);
		StringBuilder sb2 = new StringBuilder(name2);
		
		//get the length of names
		int m=sb1.length();
		int n=sb2.length();
		
		//loop through both the names find the common characters
		for(int i=0;i<m;i++) {
			for(int j=0;j<n;j++) {
				//if a matching character is found replace it with "0"
				if(sb1.charAt(i)==sb2.charAt(j)) {
					sb1.setCharAt(i, '0');
					sb2.setCharAt(j, '0');
				}
			}
		}
		//=======================STEP 1 COMPLETED========================
		// Initialize variables to count non-zero characters in both strings
        int x1 = 0;
        int y1 = 0;
        String s1 = "";
        String s2 = "";
        // Convert StringBuilder back to String
        s1 = sb1.toString();
        s2 = sb2.toString();
        // Count and print non-"0" characters in the first string
        for (int i = 0; i < s1.length(); i++) {
            if (s1.charAt(i) != '0') {
                System.out.print(" " + s1.charAt(i));
                x1 += 1;
            }
        }
        System.out.println();
        System.out.println("First String: " + x1);
		
     // Count and print non-"0" characters in the second string
        for (int i = 0; i < s2.length(); i++) {
            if (s2.charAt(i) != '0') {
                System.out.print(" " + s2.charAt(i));
                y1 += 1;
            }
        }
        System.out.println();
        System.out.println("Second String: " + y1);
        //=======================STEP 2 COMPLETED========================
        // Sum of remaining characters in both strings
        int x = x1 + y1;
        System.out.println("Length is: " + x);
        // Initialize the FLAMES string
        String flames = "flames";
        StringBuilder sb3 = new StringBuilder(flames);
        char flameResult = 0;
        // Loop until only one character is left in the StringBuilder
        while (sb3.length() != 1) {
            int y = x % sb3.length();
            String temp;
            // Determine the substring to keep based on the remainder
            if (y != 0) {
                temp = sb3.substring(y) + sb3.substring(0, y - 1);
            } else {
                temp = sb3.substring(0, sb3.length() - 1);
            }
            // Update the StringBuilder with the remaining characters
            sb3 = new StringBuilder(temp);
            flameResult = sb3.charAt(0);
        }
        System.out.println(flameResult);
        //=======================STEP 3 COMPLETED========================
     // Determine the relationship based on the last remaining character of FLAMES
        switch (flameResult) {
            case 'f':
                System.out.println(name1 + " and " + name2 + " are Friends");
                break;
            case 'l':
                System.out.println(name1 + " and " + name2 + " are in Love");
                break;
            case 'a':
                System.out.println(name1 + " and " + name2 + " are in Affection");
                break;
            case 'm':
                System.out.println(name1 + " and " + name2 + " are going to Marry");
                break;
            case 'e':
                System.out.println(name1 + " and " + name2 + " are Enemies");
                break;
            case 's':
                System.out.println(name1 + " and " + name2 + " are Sibling");
                break;
        }
    }
}

