package FindLongestWord;

import java.util.Scanner;

public class Main {
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the string");
		String input=sc.nextLine();
		
		System.out.println(UserMainCode.getLargestWord(input));
		
	}
}
