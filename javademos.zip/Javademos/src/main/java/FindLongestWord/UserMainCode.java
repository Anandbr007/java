package FindLongestWord;

import java.util.StringTokenizer;

public class UserMainCode {
	
	static String getLargestWord(String input) {
		String temp="";
		StringTokenizer str=new StringTokenizer(input," ");
		while(str.hasMoreTokens()) {
			String s=str.nextToken();
			if(s.length()>temp.length()) {
				temp=s;
			}
		}
		return temp;
		
	}
}
