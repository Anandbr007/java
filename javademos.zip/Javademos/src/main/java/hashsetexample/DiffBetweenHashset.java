package hashsetexample;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;

import java.util.Scanner;




public class DiffBetweenHashset {
	
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	HashSet<Integer> hs=new HashSet<Integer>();
	HashSet<Integer> hs1=new HashSet<Integer>();
	HashSet<Integer> hs2=new HashSet<Integer>();
	System.out.println("enter the length");
	int n=sc.nextInt();
	System.out.println("enter the elements");
	for(int i=0;i<n;i++) {
		hs.add(sc.nextInt());
	}
	System.out.println("enter the elements");
	for(int i=0;i<n;i++) {
		hs1.add(sc.nextInt());
	}
	
	hs.removeAll(hs1);
		
	int res1=Collections.max(hs)+Collections.min(hs);
	System.out.println(res1);
}
}
