package hashsetexample;

import java.util.HashMap;
import java.util.HashSet;


public class UserMainCode {

	static int sizeOfResultandHashMap(HashMap<Integer,String> hs) {
		
		HashMap<Integer,String> hs1=new HashMap<Integer,String>(hs);
	
		for(int i:hs.keySet()) {
		if(i%4==0) {
			hs1.remove(i);
		}
		}
		
		return hs1.size();
		
	}
}
