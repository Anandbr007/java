package Unittesting;



public class Wallet {
	private float balance;
	
	public void deposit(double d) {

		if(d<0)
			throw new IllegalArgumentException();		
		else {
			balance+=d;
		}
	}

	public void withdraw(double d) {
		
		if(balance<d||d<0)
			throw new IllegalArgumentException();
		else {
			balance-=d;
		}
	}

	public double getBalance() {
	
		return balance;
	}

	

}
