package Unittesting;


import java.util.List;


public class LexicographicPermutations {

	public static String generateNextPermutation(String s) {
		char temp;
		char[] res=s.toCharArray();
		for(int i=s.length()-1;i>=0;i--) {
			if(res[i]>res[i-1]) {
				temp=res[i];
				res[i]=res[i-1];
				res[i-1]=temp;
			}
		}
		
		
		return res;
		
	}
	
	public static List<String> listgetAllPermutations(){
		return null;
		
	}
}
