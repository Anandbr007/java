package Unittesting;


public class PackageStatusFinder {
	public static String solve(String input) {
		
		if(input==null || input.length()==0) {
			return "No Status";	
			}		
		String[] result=input.toLowerCase().split(";");
		return result[result.length-1];	
		
	}

}
