package MethodReference;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class StreamExample2 {

	public static void main(String[] args) {
		List<Person> al=new ArrayList<Person>();
		al.add(new Person("sanyo", 29));
		al.add(new Person("roshan",28));
		al.add(new Person("amith", 27));
		
		al.stream()
				.filter(i->i.getAge()>27)
				.forEach(p->System.out.println(p.getName()));
		
	}
}
