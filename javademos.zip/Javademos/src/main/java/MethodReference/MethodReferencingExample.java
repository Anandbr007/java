package MethodReference;

interface StringtoIntConvertor{
	int convert(String str);
}

public class MethodReferencingExample {
	public static int StringToint(String input) {
		int i=Integer.parseInt(input);
		return i;
	}
	public static void main(String[] args) {
		//using lambda expression
//		Intfunction squareFunction = number -> number * number;
//        int result = squareFunction.apply(5);
//        System.out.println("Square of 5 is: " + result);
		//use static method reference
		StringtoIntConvertor obj = Integer::parseInt;
        int result2 = obj.convert("45");
        System.out.println("the integer is: " + result2);
	}
	
}
