package MethodReference;
interface Intfunction {
	int apply(int x);
}
public class MethodReferencing {

		public static int square(int number) {
			return number*number;
		}
		public static void main(String[] args) {
			//using lambda expression
			Intfunction squareFunction = number -> number * number;
	        int result = squareFunction.apply(5);
	        System.out.println("Square of 5 is: " + result);
			//use static method reference
	        Intfunction squareFunction2 = MethodReferencing::square;
	        int result2 = squareFunction2.apply(5);
	        System.out.println("Square of 5 is: " + result2);
		}
	}

