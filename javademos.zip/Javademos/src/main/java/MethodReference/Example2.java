package MethodReference;

import java.util.Arrays;
import java.util.List;

public class Example2 {

	public static void main(String[] args) {
		List<String> strings=Arrays.asList("roshan","rainbow","playground");
		//using lambda
//		strings.forEach((str)->System.out.println(str));
		//to find length
//		strings.forEach((str)->System.out.println(str.length()));
		//using method referncing
		strings.forEach(System.out::println);
		strings.forEach(String::length);
}
}