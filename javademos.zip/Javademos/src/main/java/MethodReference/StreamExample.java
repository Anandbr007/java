package MethodReference;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;





public class StreamExample {
public static void main(String[] args) {
	List<Integer> al =new ArrayList<Integer>();
	al.add(1);
	al.add(2);
	al.add(3);
	al.add(4);
	al.add(5);
//	int num=0;
//	for(int i:al) {
//		if(i%2==0) {
//			al.set(al.indexOf(i), i*2);
//			
//		}
//	}
//	System.out.println(al);
	
	//stream
	List<Integer> doubledNumbers=al.stream()
							.filter(i->i%2==0)//filter the even
							.map(num->num*2)
							.collect(Collectors.toList());//collect the results
	doubledNumbers.forEach(System.out::println);
}
}


