package AbstractClassExample;

public abstract class Shape {

	static String Color;
	public abstract double calculateArea();
	
	public static void setColor(String colour) {
		Color=colour;
		System.out.println("the colour:"+Color);
	}
	
}
