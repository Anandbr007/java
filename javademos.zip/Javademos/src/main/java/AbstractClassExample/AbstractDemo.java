package AbstractClassExample;

public class AbstractDemo {

	public static void main(String[] args) {
		Circle c=new Circle();
		Square s=new Square();
		c.calculateArea();
		c.setColor("Red");
		
		s.calculateArea();
		s.setColor("Green");
		
	}
}
