package AbstractClassExample;

public class Square extends Shape {

	
	public double calculateArea() {
		double l=4.0,b=4.0;
		double area=l*b;
		System.out.println("area is :"+area);
		return area;
	}

}
