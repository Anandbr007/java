package AbstractClassExample;

public class Circle extends Shape{

	
	public double calculateArea() {
		double r=5.0;
		double area=3.14*r*r;
		System.out.println("area is:"+area);
		return area;
	}
	
	

}
