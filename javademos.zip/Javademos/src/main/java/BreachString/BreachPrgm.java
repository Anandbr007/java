package BreachString;

import java.util.Scanner;
import java.util.StringTokenizer;



public class BreachPrgm {
	
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the string");
	String input=sc.nextLine();
	String in=input.toLowerCase();
	BreachPrgm obj=new BreachPrgm();
	int res=obj.findBreachCount(in);
	System.out.println(res);
}
int findBreachCount(String input) {
	int count=0;
	StringTokenizer str=new StringTokenizer(input,";");
	while(str.hasMoreTokens()) {
		if(str.nextToken().contains("breach")) {
			count++;
		}
	}
	return count;
}
}
