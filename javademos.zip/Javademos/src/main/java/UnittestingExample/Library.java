package UnittestingExample;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Library {
List<Book> books=new ArrayList<Book>();

	public boolean AddBook(Book book) {
		for(Book existingBook:books) {
			if (existingBook.equals(book)) {
				return false;
			}
		}
		books.add(book);
		return true;
	}
	
	public boolean removeBook(Book book) {
		return books.remove(book);
	}
	
	public boolean isBookAvailable(String title) {
		for(Book book:books) {
			if(book.getTitle().equals(title))
				return true;
		}
		return false;
		
	}
	
	public List<Book> findBooksbyAuthor(String author){
		return books.stream().filter(book->book.getAuthor().equals(author)).collect(Collectors.toList());
		
	}
	
}  
