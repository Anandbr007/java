package sumofsquaresodEvenDigit;

import java.util.Scanner;

public class SumofSquare {
	
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	int n=sc.nextInt();
	
	System.out.println(UserMainCode.sumOfSquareofEvenDigits(n));
}

}

class UserMainCode{
	public static int sumOfSquareofEvenDigits(int num){
		int result=0;
		
		while(num>0) {
			int n=num;
			int r=num%10;
			if(r%2==0) {
				result=result+(r*r) ;
			}
		    num=num/10;
		}
		
		return result;
		
	}
}
