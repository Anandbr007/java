package libraryManagement;

public class LibraryMember {
	private String name;
	private String memberId;
	private int booksCheckedOut;
	
	public LibraryMember(String name,String memberId,int booksCheckedOut) {
		this.name=name;
		this.memberId=memberId;
		this.booksCheckedOut=booksCheckedOut;
	}
	
	int checkoutBook(String memId) {
		if(memId!=null && memId==memberId) {
		booksCheckedOut++;
		return booksCheckedOut;
		}
		else if(memberId==null)
		
		{
			return -2;
		}
		else
			return 0;
			
		
	}
	
	void displayMemberInfo(int booksCheckedOut) {
		System.out.println("Member Name: "+name+","+" Member ID: "+memberId+","+" Books Checked Out: "+booksCheckedOut);
	}
}
