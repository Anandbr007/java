package libraryManagement;

import java.util.Scanner;

public class UserInteraction {
	static String title;
	static String author;
	static String isbn;
	static String name;
	static String memberId;
	public static LibraryMember lm;
	
	void createBook() {
		
//		title, author, ISBN;
		Scanner sc=new Scanner(System.in);
		
		System.out.println("enter the title of the book"); 
		title=sc.nextLine();
		
		System.out.println("enter the author of the book"); 
		 author=sc.nextLine();
		
		System.out.println("enter the isbn of the book"); 
		isbn=sc.nextLine();
		
		Book bo=new Book(title, author, isbn);
	}
	
	void createLibraryMember() {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter member name"); 
		name=sc.nextLine();
		
		System.out.println("enter the MemberId"); 
		memberId=sc.nextLine();
		
		lm=new LibraryMember(name, memberId, 0);
	}
	
	void manageCheckout() {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Select a member for checkout (enter member ID): ");
		String memId=sc.nextLine();
		
//		lm=new LibraryMember(name, memberId, 0);
		
		int result=lm.checkoutBook(memId);
		
		if(result==0) {
			System.out.println("Member Id does not exist");
		}
		else if(result==-2)
			System.out.println("id null");
		else {
			displayCheckout(name,result);
		}
	
	}
	
	void displayCheckout(String name,int count) {
//		lm=new LibraryMember(name, memberId, 0);
		System.out.println("Checking out a book for "+name+"...");
		lm.displayMemberInfo(count);
	}
	public static void main(String[] args) {
		UserInteraction ui=new UserInteraction();
		ui.createBook();
		ui.createLibraryMember();
		

		
		Book b=new Book(title, author, isbn);
		b.displayBookInfo();
		
		
		lm=new LibraryMember(name, memberId, 0);
		lm.displayMemberInfo(0);
		ui.manageCheckout();
		
		
		
	}
}
