package libraryManagement;

import java.util.Scanner;

public class Book {

	private String title;
	private String autho;
	private String isbn;
	
	public Book(String title,String autho,String isbn) {
		this.title=title;
		this.autho=autho;
		this.isbn=isbn;
	}
	
	void displayBookInfo() {
		System.out.println("Title: "+title+"," +"Author: "+autho+","+" ISBN: "+isbn);
	}
	
	
}


