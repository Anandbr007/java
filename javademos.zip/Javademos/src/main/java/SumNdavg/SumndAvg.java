package SumNdavg;

import java.util.Scanner;

public class SumndAvg {

	public static void main(String[] args) {
		SumndAvg obj=new SumndAvg();
//		obj.AddnAvg();
		obj.Mark();
	}
	
	void AddnAvg(int a,int b,int c,int d,int e) {
		double avg=(a+b+c+d+e)/5;
		System.out.println("sum is :"+(a+b+c+d+e));
		System.out.println("avg is :"+avg);
		this.grade(avg);
	}
	
	void Mark() {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("mark1 :");
		int mark1=sc.nextInt();
		
		
		System.out.println("mark2 :");
		int mark2=sc.nextInt();
		
	
		System.out.println("mark3 :");
		int mark3=sc.nextInt();
		
		
		System.out.println("mark4 :");
		int mark4=sc.nextInt();
		
		
		System.out.println("mark5 :");
		int mark5=sc.nextInt();
		
		this.AddnAvg(mark1,mark2,mark3,mark4,mark5);
	}
	
	void grade(double mark) {
		if(mark==100) {
			System.out.println("grade : Distinction");
		}
		else if(mark<100 && mark>=85) {
			System.out.println("grade : First Class");
		}
		else if(mark<85 && mark>=75) {
			System.out.println("grade : Secind Class");
		}
		else if(mark<75 && mark>=65) {
			System.out.println("grade : Pass");
		}
		else {
			System.out.println("grade : Fail");
		}
	}
	
	
}
