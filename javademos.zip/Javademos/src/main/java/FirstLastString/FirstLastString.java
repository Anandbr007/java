package FirstLastString;

import java.util.Scanner;

public class FirstLastString {
public static void main(String[] args) {
	
	Scanner sc=new Scanner(System.in);
	
	System.out.println("enter a string");
	String input=sc.nextLine();
	System.out.println("enter the limit ");
	int lim=sc.nextInt();
	System.out.println(UserMainCode.methodformNewWord(lim,input));
}
}

class UserMainCode{
	static String methodformNewWord(int lim,String input) {
		String result="";
		int len=input.length();
		String first=input.substring(0, lim);
		String second=input.substring(len-lim, len);
		result=first.concat(second);
		return result;
	}
}
