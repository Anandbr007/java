package FileHandling;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Example1Read {
public static void main(String[] args) throws IOException {
	try {
//		FileReader fr=new FileReader("C:\\Users\\268852\\eclipse-workspace\\Javademos\\sample.txt");	
//		char arr[]=new char[100];
//		fr.read(arr);
//		System.out.println(arr);
//		fr.close();
		char arr1[]=new char[100];
		String path="C:\\Users\\268852\\eclipse-workspace\\Javademos\\sample.txt";
		BufferedReader br=new BufferedReader(new FileReader(path));
		String line;
		
		while((line=br.readLine())!=null) {
			System.out.println(line);

			StringBuffer str=new StringBuffer(line);
			System.out.println(str);
		}
		
		
		
		
		
		br.close();
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
}
