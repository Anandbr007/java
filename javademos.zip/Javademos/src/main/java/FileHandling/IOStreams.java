package FileHandling;

public class IOStreams {
public static void main(String[] args) {
	
	//types of streams
	
	//Byte streams-Byte stream carries out 8 bit i/p and o/p operations
	//inputstream and outputStream->used to read and write data
	//Character Streams-used to transmit the data in 16 bits
	
	
	//input stream is used to read data
	//output stream is used to write data
	
	
	//methods in input stream
	
	//read()->read byte of data
	//read(byte[] b)->read byte of data
	//available()->returns the number of bytes that can be read
	//mark(int readlimit)-marks the current position
	//markSupported()-returns true if mark is supported
	//skip(long n)-skips the specified no. of bytes
	//close()-close the stream
	
	//methods in output stream
	
	//write()-write the byte of data
	//write(byte[] b)
	//flush()-force to write all data in o/p stream
	//close()
}
}
