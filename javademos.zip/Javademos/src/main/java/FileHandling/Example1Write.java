package FileHandling;

import java.io.File;
import java.io.FileWriter;

public class Example1Write {

	public static void main(String[] args) {
		try {
			FileWriter fw=new FileWriter("C:\\Users\\268852\\eclipse-workspace\\Javademos\\sample.txt");
			String input="select * from ipl.csv where season > 2014 and city = 'Bangalore'";
			fw.write(input);
			
			fw.close();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
	}
}
