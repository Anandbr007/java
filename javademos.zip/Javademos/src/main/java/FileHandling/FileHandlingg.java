package FileHandling;

import java.io.File;

public class FileHandlingg {

	//file class-->java.io package
	//which is used to perform file operations on files and directories
	//file class is a super class of all classes in java.io package
	
	//createNewFile()-creates a new,empty file
	//read()-reads the contents of the file
	//write()-writes the contents into the file
	//delete()-delete the file
	
	//Filereader fr=new Filereader("location");
	//fr.read(arr);
	
	public static void main(String[] args) {
		//create an object of a file class
		//project path
		String projectPath=System.getProperty("user.dir");
		System.out.println(projectPath);
		File f=new File(projectPath+"\\sample.txt");//file path as string
		try {
			boolean value=f.createNewFile();
			if(value) {
				System.out.println("new file is created");
			}else {
				System.out.println("file already exists");
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.getStackTrace();
		}
		
	}

}
