package removeVowels;

import java.util.Scanner;

public class RemoveVowels {
	
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.print("enter the name :");
	String name=sc.next();
	StringBuffer name1=new StringBuffer(name);
	
	
	for(int i=0;i<name1.length();i++) {
		if(name1.charAt(i)=='a' || name1.charAt(i)=='e' || name1.charAt(i)=='i' || name1.charAt(i)=='o' || name1.charAt(i)=='u') {
			name1.deleteCharAt(i);
			
		}
	}
	System.out.println(name1);
}
}
