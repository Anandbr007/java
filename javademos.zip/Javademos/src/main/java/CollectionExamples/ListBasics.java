package CollectionExamples;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Scanner;

public class ListBasics {

	public static void main(String[] args) {
		ArrayList<String> al=new ArrayList<String>();
		al.add("Nagercoil");
		al.add("pathanamthitta");
		al.add("konni");
		al.add("trivandrum");
		al.add("Chinnakada");
		
		Iterator<String> itr=al.iterator();
		while(itr.hasNext()) {
			System.out.println("City : "+itr.next());
		}
		//add
		Scanner sc=new Scanner(System.in);
		System.out.println("Add the city: \n1)At end of the list\n2)At specific index");
		int n=sc.nextInt();
		if(n==1) {
				System.out.println("enter city name");
				al.add(sc.nextLine());
				}
		else if(n==2) {
			System.out.println("enter index number");
			int i=sc.nextInt();
			al.add(i,sc.nextLine());
			}
			
		
		
		//remove
		System.out.println("remove city: \n1)remove by element\n2)remove by index");
		int n1=sc.nextInt();
		if(n1==1) {
				System.out.println("enter city name");
				al.remove(sc.nextLine());
		}
		else if(n1==2) {
			System.out.println("enter index number");
			int i=sc.nextInt();
			al.remove(i);
		}
			
		
		
		//modify
		System.out.println("enter index number ");
		int n2=sc.nextInt();
		System.out.println("enter City name ");
		String city=sc.nextLine();
		
		al.set(n2, city);
		
		//Search for an Element
		System.out.println("enter the element to be searched:");
		String input=sc.nextLine();
		if(al.contains(input))
			System.out.println("the element is present ");
		else
			System.out.println("th element is not present");
		
		//Size of the List
		System.out.println("the size of the list is:"+al.size());
		
		//ADVANCED PROJECT
		
		//Sorting
		Collections.sort(al);
		Iterator<String> itr1=al.iterator();
		while(itr1.hasNext()) {
			System.out.println("the sorted list is:"+itr1.next());
		}
		
		
		
	}
}
	

