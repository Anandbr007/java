package StringRemoveDuplicateNdSort;

import java.util.TreeSet;

public class UserMainCode {

	static TreeSet orderElements(String[] input) {
		
		TreeSet<String> ts=new TreeSet<String>();
		for(int i=0;i<input.length;i++) {
			ts.add(input[i]);
		}
		
		return ts;
		
	}
}
