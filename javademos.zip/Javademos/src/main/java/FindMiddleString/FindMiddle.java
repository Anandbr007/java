package FindMiddleString;

import java.util.Scanner;

public class FindMiddle {
	
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter a string of even length");
	String input=sc.nextLine();
	System.out.println(UserMainCode.getMiddleChars(input));
}
}

class UserMainCode{
	static String getMiddleChars(String input) {
		String result="";
		int len=input.length();
		int half=len/2;
		result = input.substring(half-1, half+1);
		return result;
	}
}
