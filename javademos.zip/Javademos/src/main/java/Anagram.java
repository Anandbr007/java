import java.util.Arrays;
import java.util.Scanner;

public class Anagram {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter 2 strings:");
		Scanner sc = new Scanner(System.in);
		String a = sc.nextLine();
		String b = sc.nextLine();
		if(isAnagram(a,b))
		{
			System.out.println("Anagram");
		}
		else {
			System.out.println("Not Anagram");
		}
	}
	private static boolean isAnagram(String a, String b) {
		// TODO Auto-generated method stub
		if(a.length()!=b.length())
		{
			return false;
		}
		char[] a1 =a.toLowerCase().toCharArray();
		char[] b1 =b.toLowerCase().toCharArray();
		Arrays.sort(a1);
		Arrays.sort(b1);
//		System.out.println(a1.toString());
		if(Arrays.equals(a1, b1))
				{
					return true;
				}
		return false;
	}
}