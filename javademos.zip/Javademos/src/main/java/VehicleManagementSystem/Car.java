package VehicleManagementSystem;

public class Car implements Vehicle {
private int maxSpeed;

public Car(int maxSpeed) {
	super();
	this.maxSpeed = maxSpeed;
}

@Override
public double getMaxSpeed() {
	// TODO Auto-generated method stub
	return 0;
}


}
