package VehicleManagementSystem;

public class MainCode {

	public static void main(String[] args) {
		Car car=new Car(20);
		Bike bike=new Bike(40);
		
		
		
	}
}
