package VehicleManagementSystem;

import java.util.Scanner;

public class Bike implements Vehicle{
	private int maxSpeed;

	public Bike(int maxSpeed) {
		super();
		this.maxSpeed = maxSpeed;
	}

	@Override
	public double getMaxSpeed() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter bike maxspeed");
		
		return 0;
	}
	
}
