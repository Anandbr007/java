package VehicleManagementSystem;

public interface Vehicle {

	double getMaxSpeed();
	
	 default void start() {
		 System.out.println("vehicle has started");
	 }
	 
	 default void stop() {
		 System.out.println("vehicle has stopped");
	 }
	 
	 static void compareSpeed(Vehicle v1, Vehicle v2) {
		 if (v1==v2) {
			System.out.println("both have same speed");
		}
		 else if (v1.getMaxSpeed()>v2.getMaxSpeed()) {
			System.out.println("v1 is faster");
	 }
		 else {
			System.out.println("v2 is faster");
		}
}
}
