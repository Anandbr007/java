package org.example;

import static org.junit.Assert.assertEquals;

import java.security.PublicKey;

import org.junit.Before;
import org.junit.Test;

import Unittesting.Calculator;

public class CalculatorTest {

private Calculator calculator;
	
	@Before
	public void setup() {
		calculator = new Calculator();
	}
	
	@Test
	public void testMultiply() {
		//assert-used to compare two values
		/*
		 * assertequals-used to compare two values
		 * asserttrue-used to compare the boolean value
		 * assertfalse-used to compare the boolean value
		 * assertNull-used to compare the object
		 * assertNotNull-used to compare the object
		 */
		
		int result = calculator.multiply(5, 5);
		assertEquals(24, result);
	}
	@Test
	public void testMultiplyWithZero() {
		assertEquals("Multiply with zero should return 0",0, calculator.multiply(0, 5));
		assertEquals("Multiply with zero should return 0",0, calculator.multiply(5, 0));

	}

	}

