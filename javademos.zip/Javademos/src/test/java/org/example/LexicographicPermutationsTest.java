package org.example;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;

import Unittesting.LexicographicPermutations;
public class LexicographicPermutationsTest {
    @Test
    public void testGenerateNextPermutation() {
        assertEquals("acb", LexicographicPermutations.generateNextPermutation("abc"));
        assertEquals("No higher permutation exists", LexicographicPermutations.generateNextPermutation("cba"));
        assertEquals("bac", LexicographicPermutations.generateNextPermutation("acb"));
    }
    @Test
    public void testGetAllPermutationsWithoutDuplicates() {
        List<String> expected = Arrays.asList("abc", "acb", "bac", "bca", "cab", "cba");
        List<String> actual = LexicographicPermutations.getAllPermutations("abc");
        assertEquals(expected.size(), actual.size());
        assertTrue(actual.containsAll(expected));
    }
    @Test
    public void testGetAllPermutationsWithDuplicates() {
        List<String> expected = Arrays.asList("aabc", "aacb", "abac", "abca", "acab", "acba", "baac", "baca", "bcaa", "caab", "caba", "cbaa");
        List<String> actual = LexicographicPermutations.getAllPermutations("aabc");
        assertEquals(expected.size(), actual.size());
        assertTrue(actual.containsAll(expected));
    }
}
