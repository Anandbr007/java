package junitests;

import org.junit.Test;

public class AnnotationHierarchy {
@Test	
public void testcase1() {
	//identifies a method as test method
	System.out.println("testcase 1");
}
@Test(expected=Exception)	
public void testcase2() {
	//identifies a method as test method
		System.out.println("testcase 2");
}
	

}
