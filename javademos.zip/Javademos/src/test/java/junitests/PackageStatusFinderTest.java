package junitests;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import Unittesting.PackageStatusFinder;

public class PackageStatusFinderTest {

    @Test
    public void testSolveWithMultipleStatuses() {
        assertEquals("on-hold", PackageStatusFinder.solve("returned;on-hold"));
        assertEquals("in-transit", PackageStatusFinder.solve("in-transit"));
        assertEquals("on-hold", PackageStatusFinder.solve("delivered;returned;on-hold"));
    }

    @Test
    public void testSolveWithSingleStatus() {
        assertEquals("returned", PackageStatusFinder.solve("returned"));
        assertEquals("delivered", PackageStatusFinder.solve("delivered"));
    }

    @Test
    public void testSolveWithEmptyStatus() {
        assertEquals("No Status", PackageStatusFinder.solve(""));
    }

    @Test
    public void testSolveWithNullStatus() {
        assertEquals("No Status", PackageStatusFinder.solve(null));
    }

    @Test
    public void testSolveWithUnexpectedStatus() {
        assertEquals("unexpected-status", PackageStatusFinder.solve("unexpected-status"));
    }

    @Test
    public void testSolveWithTrailingDelimiter() {
        assertEquals("in-transit", PackageStatusFinder.solve("in-transit;"));
    }

    @Test
    public void testSolveWithLeadingAndTrailingDelimiters() {
        assertEquals("on-hold", PackageStatusFinder.solve(";on-hold;"));
    }
}
