package junitests;

import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.hamcrest.Matchers.hasProperty;


import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.hamcrest.core.Is.is;
import UnittestingExample.Book;
import UnittestingExample.Library;

public class LibrarywithHamcrestndJunit {

private Library library;
	
	@BeforeEach
	void setup() {
		library=new Library();
	}
	
	@Test
	void addBookSuccessfully() {
		Book book=new Book("Harry potter","Jk Rowling");
		//using Junit assertion
//		assertTrue(library.AddBook(book));
		//additional check with hamcrest 
		assertThat(library.AddBook(book),is(true));
	}
	@Test
	void addBookFailsonDuplicate() {
		Book book=new Book("i too had a love story","Ravinder singh");
		library.AddBook(book);
		//using Junit assertion
//		assertTrue(library.AddBook(book));
		//additional check with hamcrest
		assertThat("Book addition should fail due to duplicate book",
				library.AddBook(book),is(false));
	}
	
	@Test
	void removeBookSuccessfully() {
		Book book=new Book("can love happen twice","Ravinder singh");
		library.AddBook(book);
		assertTrue(library.removeBook(book));
	}
	
	@Test
	void removeBookFailWhenitisnotpresent() {
		Book book=new Book("Wings of fire","APJ abdul kalam");
		assertThat(library.removeBook(book),is(false));
	}
	@Test
	void isBookAvailable() {
//		assertTrue(library.isBookAvailable("Harry potter"));
		assertThat(library.isBookAvailable("Harry potter"),is(false));
	}
	@Test
	void findBooksByAuthorwithMultipleBooks() {
		library.AddBook(new Book("alchemist","paulo coelho"));
		library.AddBook(new Book("The subtle art of not giving a f","Mark Manson"));
		
		List<Book> books=library.findBooksbyAuthor("Mark Manson");
		
		assertEquals(2,books.size());
		
		assertThat(books,hasProperty("author",is("Mark Manson")));
		assertThat(books,hasProperty("title",is("The subtle art of not giving a f")));
	}

}
